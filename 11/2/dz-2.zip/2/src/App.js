
import PostComponents from "./components/PostComponents";
import "./App.css";

const App = () => {


  // console.log(users)

  return (
    <>
      
      <PostComponents />

    </>
  )
};

export default App;
