import { users } from './assets/users.js'
import { capsuls } from './assets/capsuls.js'
import styles from './PostComponents.module.css'
import PostItem from './PostItem.js'
import CapsulItem from './CapsulItem.js'
const PostComponents = () => {

 
  return (
    <div className={styles.wrapContainers}>
      <div className={styles.container}>
        <h1>Users</h1>
        {users.map((user) => <PostItem key={user.id} user={user} />)}
      </div >
      <div className={styles.container}>
        <h1>Capsules</h1>
        {capsuls.map((capsul) => <CapsulItem key={Math.random()} capsul={capsul} />)}
      </div >
      
    </div>
  )



}
export default PostComponents 