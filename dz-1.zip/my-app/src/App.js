// import logo from './logo.svg';
import './App.css';
import Character1 from './Character1';
import Character2 from './Character2';
import Character3 from './Character3';
import Character4 from './Character4';
import Character5 from './Character5';
import Character6 from './Character6';
import Character7 from './Character7';
import Character8 from './Character8';
import Character9 from './Character9';
import Character10 from './Character10';
const App = ()=> {
  return (
    <div className='container' >
      <Character1/>
      <Character2 />
      <Character3 />
      <Character4 />
      <Character5 />
      <Character6 />
      <Character7 />
      <Character8 />
      <Character9 />
      <Character10 />
    </div>
    
  );
}

export default App;
