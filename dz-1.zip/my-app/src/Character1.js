import DescribeCharacter from "./DescribeCharacter"

const Character1 = () => {
  const char = { "id": 450, "name": "Roy's Wife", "status": "Alive", "species": "Human", "type": "Game", "gender": "Male", "origin": { "name": "Roy: A Life Well Lived", "url": "https://rickandmortyapi.com/api/location/32" }, "location": { "name": "Roy: A Life Well Lived", "url": "https://rickandmortyapi.com/api/location/32" }, "image": "https://rickandmortyapi.com/api/character/avatar/450.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/13"], "url": "https://rickandmortyapi.com/api/character/450", "created": "2018-05-01T13:57:55.888Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character1