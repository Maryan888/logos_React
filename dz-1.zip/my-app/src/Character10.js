import DescribeCharacter from "./DescribeCharacter"

const Character10 = () => {
  const char = { "id": 20, "name": "Ants in my Eyes Johnson", "status": "unknown", "species": "Human", "type": "Human with ants in his eyes", "gender": "Male", "origin": { "name": "unknown", "url": "" }, "location": { "name": "Interdimensional Cable", "url": "https://rickandmortyapi.com/api/location/6" }, "image": "https://rickandmortyapi.com/api/character/avatar/20.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/8"], "url": "https://rickandmortyapi.com/api/character/20", "created": "2017-11-04T22:34:53.659Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character10