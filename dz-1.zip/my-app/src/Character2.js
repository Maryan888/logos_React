import DescribeCharacter from "./DescribeCharacter"

const Character2 = () => {
  const char = { "id": 418, "name": "Mrs. Sullivan's Boyfriend", "status": "Alive", "species": "Human", "type": "Necrophiliac", "gender": "Male", "origin": { "name": "Interdimensional Cable", "url": "https://rickandmortyapi.com/api/location/6" }, "location": { "name": "Interdimensional Cable", "url": "https://rickandmortyapi.com/api/location/6" }, "image": "https://rickandmortyapi.com/api/character/avatar/418.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/8"], "url": "https://rickandmortyapi.com/api/character/418", "created": "2018-04-15T21:43:43.867Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character2