import DescribeCharacter from "./DescribeCharacter"

const Character3 = () => {
  const char = { "id": 263, "name": "Pibbles Bodyguard", "status": "Alive", "species": "Alien", "type": "Hairy alien", "gender": "Male", "origin": { "name": "unknown", "url": "" }, "location": { "name": "St. Gloopy Noops Hospital", "url": "https://rickandmortyapi.com/api/location/16" }, "image": "https://rickandmortyapi.com/api/character/avatar/263.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/19"], "url": "https://rickandmortyapi.com/api/character/263", "created": "2017-12-31T13:43:30.513Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character3