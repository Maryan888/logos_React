import DescribeCharacter from "./DescribeCharacter"

const Character4 = () => {
  const char = { "id": 620, "name": "Ramamama Lord", "status": "Alive", "species": "Human", "type": "Soulless Puppet", "gender": "Male", "origin": { "name": "Story Train", "url": "https://rickandmortyapi.com/api/location/96" }, "location": { "name": "Story Train", "url": "https://rickandmortyapi.com/api/location/96" }, "image": "https://rickandmortyapi.com/api/character/avatar/620.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/37"], "url": "https://rickandmortyapi.com/api/character/620", "created": "2020-08-06T15:58:14.525Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character4