import DescribeCharacter from "./DescribeCharacter"

const Character5 = () => {
  const char = { "id": 614, "name": "Mr. Celery & Friends", "status": "Alive", "species": "unknown", "type": "Soulless Puppet", "gender": "Genderless", "origin": { "name": "Ricks’s Story", "url": "https://rickandmortyapi.com/api/location/100" }, "location": { "name": "Ricks’s Story", "url": "https://rickandmortyapi.com/api/location/100" }, "image": "https://rickandmortyapi.com/api/character/avatar/614.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/37"], "url": "https://rickandmortyapi.com/api/character/614", "created": "2020-08-06T12:51:12.254Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character5