import DescribeCharacter from "./DescribeCharacter"

const Character6 = () => {
  const char = { "id": 57, "name": "Borpocian", "status": "Alive", "species": "Alien", "type": "Elephant-Person", "gender": "Male", "origin": { "name": "unknown", "url": "" }, "location": { "name": "unknown", "url": "" }, "image": "https://rickandmortyapi.com/api/character/avatar/57.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/22"], "url": "https://rickandmortyapi.com/api/character/57", "created": "2017-11-05T11:38:29.459Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character6