import DescribeCharacter from "./DescribeCharacter"

const Character7 = () => {
  const char = { "id": 594, "name": "Floaty Bloody Man", "status": "Dead", "species": "Human", "type": "Half Soulless Puppet", "gender": "Male", "origin": { "name": "Tickets Please Guy Nightmare", "url": "https://rickandmortyapi.com/api/location/98" }, "location": { "name": "Tickets Please Guy Nightmare", "url": "https://rickandmortyapi.com/api/location/98" }, "image": "https://rickandmortyapi.com/api/character/avatar/594.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/37"], "url": "https://rickandmortyapi.com/api/character/594", "created": "2020-08-06T09:54:08.973Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character7