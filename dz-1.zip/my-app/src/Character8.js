import DescribeCharacter from "./DescribeCharacter"

const Character8 = () => {
  const char = { "id": 806, "name": "Metaphor for Capitalism", "status": "Dead", "species": "Humanoid", "type": "", "gender": "Male", "origin": { "name": "Citadel of Ricks", "url": "https://rickandmortyapi.com/api/location/3" }, "location": { "name": "Citadel of Ricks", "url": "https://rickandmortyapi.com/api/location/3" }, "image": "https://rickandmortyapi.com/api/character/avatar/806.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/51"], "url": "https://rickandmortyapi.com/api/character/806", "created": "2021-11-02T13:33:10.457Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character8