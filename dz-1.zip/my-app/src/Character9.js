import DescribeCharacter from "./DescribeCharacter"

const Character9 = () => {
  const char = { "id": 18, "name": "Antenna Morty", "status": "Alive", "species": "Human", "type": "Human with antennae", "gender": "Male", "origin": { "name": "unknown", "url": "" }, "location": { "name": "Citadel of Ricks", "url": "https://rickandmortyapi.com/api/location/3" }, "image": "https://rickandmortyapi.com/api/character/avatar/18.jpeg", "episode": ["https://rickandmortyapi.com/api/episode/10", "https://rickandmortyapi.com/api/episode/28"], "url": "https://rickandmortyapi.com/api/character/18", "created": "2017-11-04T22:25:29.008Z" }
  return (
    <DescribeCharacter id={char.id}
      name={char.name}
      status={char.status}
      species={char.species}
      gender={char.gender}
      image={char.image}
    />


  )
}

export default Character9