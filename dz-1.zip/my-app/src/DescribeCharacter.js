const DescribeCharacter = (props) => {
 
  return (
    <div>
      <p>{props.id}</p>
      <h2>{props.name}</h2>
      <p>{props.status}</p>
      <p>{props.species}</p>
      <p>{props.gender}</p>
      <img src={props.image} alt="" />
    </div>
  )
}

export default DescribeCharacter