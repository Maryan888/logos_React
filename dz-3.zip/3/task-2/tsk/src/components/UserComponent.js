

const UserComponent = (props) => {
  
  return (
    <div>
      
     <button onClick={props.openPostHandler}>show posts</button>
      
    </div>
  )
}
export default UserComponent