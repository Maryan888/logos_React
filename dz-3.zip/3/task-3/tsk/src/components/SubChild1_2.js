const SubChild1_2 = () => {
  return (
    <div>
      
    </div>
  )

}
export default SubChild1_2